
/*!
 *  @file LSM6DS.cpp Adafruit LSM6DS 6-DoF Accelerometer library
 *
 *  @section intro_sec Introduction
 *
 * 	I2C Driver base for Adafruit LSM6DS 6-DoF Accelerometer
 *      and Sleep library for 2468 LoRa Pet Tracker Capstone
 *
 *  @section dependencies Dependencies
 *  This library depends on the Adafruit BusIO library
 *  This library depends on the Adafruit Unified Sensor library
 * 
 *  @section author Author
 *
 *  Margaret Lee
 *
 */

#include "Arduino.h"
#include <Wire.h>

#include "LSM6DS.h"

static const float _data_rate_arr[] = {
    [LSM6DS_RATE_SHUTDOWN] = 0.0f,    [LSM6DS_RATE_12_5_HZ] = 12.5f,
    [LSM6DS_RATE_26_HZ] = 26.0f,      [LSM6DS_RATE_52_HZ] = 52.0f,
    [LSM6DS_RATE_104_HZ] = 104.0f,    [LSM6DS_RATE_208_HZ] = 208.0f,
    [LSM6DS_RATE_416_HZ] = 416.0f,    [LSM6DS_RATE_833_HZ] = 833.0f,
    [LSM6DS_RATE_1_66K_HZ] = 1660.0f, [LSM6DS_RATE_3_33K_HZ] = 3330.0f,
    [LSM6DS_RATE_6_66K_HZ] = 6660.0f, [LSM6DS_RATE_1_6_Hz] = 1.6f,
};

/*!
 *    @brief  Instantiates a new LSM6DS class
 */
LSM6DS::LSM6DS(void) {}

/*!
 *    @brief  Cleans up the LSM6DS
 */
LSM6DS::~LSM6DS(void) { delete temp_sensor; }

/*!  @brief  Unique subclass initializer post i2c/spi init
 *   @param sensor_id Optional unique ID for the sensor set
 *   @returns True if chip identified and initialized
 */
bool LSM6DS::_init(int32_t sensor_id) {
  (void)sensor_id;

  // delete objects if sensor is reinitialized
  delete temp_sensor;
  delete accel_sensor;

  temp_sensor = new LSM6DS_Temp(this);
  accel_sensor = new LSM6DS_Accelerometer(this);

  return true;
};

/*!
 *    @brief  Read chip identification register (protected)
 *    @returns 8 Bit value from WHO_AM_I register
 */
uint8_t LSM6DS::chipID(void) {
  Adafruit_BusIO_Register chip_id = Adafruit_BusIO_Register(i2c_dev, WHO_AM_I);
  // Serial.print("Read ID 0x"); Serial.println(chip_id.read(), HEX);

  return chip_id.read();
}

/*!
 *    @brief  Read Status register (protected)
 *    @returns 8 Bit value from Status register
 */
uint8_t LSM6DS::status(void) {
  Adafruit_BusIO_Register status_reg = Adafruit_BusIO_Register(i2c_dev, STATUS_REG);
  return status_reg.read();
}

/*!
 *    @brief  Sets up the hardware and initializes I2C
 *    @param  i2c_address
 *            The I2C address to be used.
 *    @param  wire
 *            The Wire object to be used for I2C connections.
 *    @param  sensor_id
 *            The user-defined ID to differentiate different sensors
 *    @return True if initialization was successful, otherwise false.
 */
boolean LSM6DS::begin_I2C(uint8_t i2c_address, TwoWire *wire, int32_t sensor_id) {
  delete i2c_dev; // remove old interface

  i2c_dev = new Adafruit_I2CDevice(i2c_address, wire);

  if (!i2c_dev->begin()) {
    return false;
  }

  return _init(sensor_id);
}

/**************************************************************************/
/*!
    @brief Resets the sensor to its power-on state, clearing all registers and
    memory
*/
void LSM6DS::reset(void) {
  Adafruit_BusIO_Register ctrl3 = Adafruit_BusIO_Register(i2c_dev, CTRL3_C);
  Adafruit_BusIO_RegisterBits sw_reset = Adafruit_BusIO_RegisterBits(&ctrl3, 1, 0);
  sw_reset.write(true);

  while (sw_reset.read()) { delay(1); }
}

/*!
    @brief  Gets an Adafruit Unified Sensor object for the temp sensor component
    @return Adafruit_Sensor pointer to temperature sensor
 */
Adafruit_Sensor *LSM6DS::getTemperatureSensor(void) {
  return temp_sensor;
}

/*!
    @brief  Gets an Adafruit Unified Sensor object for the accelerometer
    sensor component
    @return Adafruit_Sensor pointer to accelerometer sensor
 */
Adafruit_Sensor *LSM6DS::getAccelerometerSensor(void) {
  return accel_sensor;
}

/**************************************************************************/
/*!
    @brief  Gets the most recent sensor event, Adafruit Unified Sensor format
    @param  accel
            Pointer to an Adafruit Unified sensor_event_t object to be filled
            with acceleration event data.

    @param  temp
            Pointer to an Adafruit Unified sensor_event_t object to be filled
            with temperature event data.

    @return True on successful read
*/
/**************************************************************************/
bool LSM6DS::getEvent(sensors_event_t *accel, sensors_event_t *temp) {
  uint32_t t = millis();
  _read();

  // use helpers to fill in the events
  fillAccelEvent(accel, t);
  fillTempEvent(temp, t);
  return true;
}

void LSM6DS::fillTempEvent(sensors_event_t *temp, uint32_t timestamp) {
  memset(temp, 0, sizeof(sensors_event_t));
  temp->version = sizeof(sensors_event_t);
  temp->sensor_id = _sensorid_temp;
  temp->type = SENSOR_TYPE_AMBIENT_TEMPERATURE;
  temp->timestamp = timestamp;
  temp->temperature = temperature;
}

void LSM6DS::fillAccelEvent(sensors_event_t *accel, uint32_t timestamp) {
  memset(accel, 0, sizeof(sensors_event_t));
  accel->version = 1;
  accel->sensor_id = _sensorid_accel;
  accel->type = SENSOR_TYPE_ACCELEROMETER;
  accel->timestamp = timestamp;
  accel->acceleration.x = accX;
  accel->acceleration.y = accY;
  accel->acceleration.z = accZ;
}

/**************************************************************************/
/*!
    @brief Gets the accelerometer data rate.
    @returns The the accelerometer data rate.
*/
lsm6ds_data_rate_t LSM6DS::getAccelDataRate(void) {
  Adafruit_BusIO_Register ctrl1 = Adafruit_BusIO_Register(i2c_dev, CTRL1_XL);
  Adafruit_BusIO_RegisterBits accel_data_rate = Adafruit_BusIO_RegisterBits(&ctrl1, 4, 4);
  return (lsm6ds_data_rate_t)accel_data_rate.read();
}

/**************************************************************************/
/*!
    @brief Sets the accelerometer data rate.
    @param  data_rate
            The the accelerometer data rate. Must be a `lsm6ds_data_rate_t`.
*/
void LSM6DS::setAccelDataRate(lsm6ds_data_rate_t data_rate) {
  Adafruit_BusIO_Register ctrl1 = Adafruit_BusIO_Register(i2c_dev, CTRL1_XL);
  Adafruit_BusIO_RegisterBits accel_data_rate = Adafruit_BusIO_RegisterBits(&ctrl1, 4, 4);
  accel_data_rate.write(data_rate);
}

/**************************************************************************/
/*!
    @brief Enables the high pass filter and/or slope filter
    @param filter_enabled Whether to enable the slope filter (see datasheet)
    @param filter The lsm6ds_hp_filter_t that sets the data rate divisor
*/
/**************************************************************************/
void LSM6DS::highPassFilter(bool filter_enabled, lsm6ds_hp_filter_t filter) {
  Adafruit_BusIO_Register ctrl8 = Adafruit_BusIO_Register(i2c_dev, CTRL8_XL);
  Adafruit_BusIO_RegisterBits HPF_en = Adafruit_BusIO_RegisterBits(&ctrl8, 1, 2);
  Adafruit_BusIO_RegisterBits HPF_filter = Adafruit_BusIO_RegisterBits(&ctrl8, 2, 5);
  HPF_en.write(filter_enabled);
  HPF_filter.write(filter);
}

/******************* Adafruit_Sensor functions *****************/
/*!
 *     @brief  Updates the measurement data for all sensors simultaneously
 */
/**************************************************************************/
void LSM6DS::_read(void) {
  Adafruit_BusIO_Register temp_reg = Adafruit_BusIO_Register(i2c_dev, OUT_TEMP, 2);

  uint8_t t_buffer[2];
  temp_reg.read(t_buffer, 2);

  rawTemp = t_buffer[1] << 8 | t_buffer[0];
  temperature = (rawTemp / temperature_sensitivity) + 25.0;

  Adafruit_BusIO_Register acc_reg = Adafruit_BusIO_Register(i2c_dev, OUT_A, 6);

  uint8_t acc_buffer[6];
  acc_reg.read(acc_buffer, 6);

  rawAccX = acc_buffer[1] << 8 | acc_buffer[0];
  rawAccY = acc_buffer[3] << 8 | acc_buffer[2];
  rawAccZ = acc_buffer[5] << 8 | acc_buffer[4];

  float accel_scale = 0.061; // range is in milli-g per bit! value for 2 g fs

  accX = rawAccX * accel_scale * SENSORS_GRAVITY_STANDARD / 1000;
  accY = rawAccY * accel_scale * SENSORS_GRAVITY_STANDARD / 1000;
  accZ = rawAccZ * accel_scale * SENSORS_GRAVITY_STANDARD / 1000;
}

/**************************************************************************/
/*!
    @brief Sets the INT1 and INT2 pin activation mode
    @param active_low true to set the pins  as active high, false to set the
   mode to active low
    @param open_drain true to set the pin mode as open-drain, false to set the
   mode to push-pull
*/
void LSM6DS::configIntOutputs(bool active_low, bool open_drain) {
  Adafruit_BusIO_Register ctrl3 = Adafruit_BusIO_Register(i2c_dev, CTRL3_C);
  Adafruit_BusIO_RegisterBits ppod_bits = Adafruit_BusIO_RegisterBits(&ctrl3, 2, 4);
  ppod_bits.write((active_low << 1) | open_drain);
}

/**************************************************************************/
/*!
    @brief Enables and disables the data ready interrupt on INT 1.
    @param drdy_temp true to output the data ready temperature interrupt
    @param drdy_g true to output the data ready gyro interrupt
    @param drdy_xl true to output the data ready accelerometer interrupt
    @param step_detect true to output the step detection interrupt (default off)
    @param activity true to output the activity/inactivity recognition interrupt (default off)
*/
void LSM6DS::configInt1(bool drdy_temp, bool drdy_g, bool drdy_xl, bool step_detect, bool activity) {
  Adafruit_BusIO_Register int1_ctrl = Adafruit_BusIO_Register(i2c_dev, INT1_CTRL);
  int1_ctrl.write((step_detect << 7) | (drdy_temp << 2) | (drdy_g << 1) | drdy_xl);

  Adafruit_BusIO_Register md1cfg = Adafruit_BusIO_Register(i2c_dev, MD1_CFG);
  Adafruit_BusIO_RegisterBits act = Adafruit_BusIO_RegisterBits(&md1cfg, 1, 7);
  act.write(activity);
}

/**************************************************************************/
/*!
    @brief Enables and disables the data ready interrupt on INT 2.
    @param drdy_temp true to output the data ready temperature interrupt
    @param drdy_g true to output the data ready gyro interrupt
    @param drdy_xl true to output the data ready accelerometer interrupt
*/
void LSM6DS::configInt2(bool drdy_temp, bool drdy_g, bool drdy_xl) {
  Adafruit_BusIO_Register int2_ctrl = Adafruit_BusIO_Register(i2c_dev, INT2_CTRL);

  Adafruit_BusIO_RegisterBits int2_drdy_bits =
      Adafruit_BusIO_RegisterBits(&int2_ctrl, 3, 0);

  int2_drdy_bits.write((drdy_temp << 2) | (drdy_g << 1) | drdy_xl);
}


/**************************************************************************/
/*!
    @brief  Gets the sensor_t data for the LSM6DS's accelerometer
*/
/**************************************************************************/
void LSM6DS_Accelerometer::getSensor(sensor_t *sensor) {
  /* Clear the sensor_t object */
  memset(sensor, 0, sizeof(sensor_t));

  /* Insert the sensor name in the fixed length char array */
  strncpy(sensor->name, "LSM6DS_A", sizeof(sensor->name) - 1);
  sensor->name[sizeof(sensor->name) - 1] = 0;
  sensor->version = 1;
  sensor->sensor_id = _sensorID;
  sensor->type = SENSOR_TYPE_ACCELEROMETER;
  sensor->min_delay = 0;
  sensor->min_value = -156.9064F; /*  -16g = 156.9064 m/s^2  */
  sensor->max_value = 156.9064F;  /* 16g = 156.9064 m/s^2  */
  sensor->resolution = 0.061;     /* 0.061 mg/LSB at +-2g */
}

/**************************************************************************/
/*!
    @brief  Gets the accelerometer as a standard sensor event
    @param  event Sensor event object that will be populated
    @returns True
*/
/**************************************************************************/
bool LSM6DS_Accelerometer::getEvent(sensors_event_t *event) {
  _theLSM6DS->_read();
  _theLSM6DS->fillAccelEvent(event, millis());

  return true;
}

/**************************************************************************/
/*!
    @brief  Gets the sensor_t data for the LSM6DS's temperature
*/
/**************************************************************************/
void LSM6DS_Temp::getSensor(sensor_t *sensor) {
  /* Clear the sensor_t object */
  memset(sensor, 0, sizeof(sensor_t));

  /* Insert the sensor name in the fixed length char array */
  strncpy(sensor->name, "LSM6DS_T", sizeof(sensor->name) - 1);
  sensor->name[sizeof(sensor->name) - 1] = 0;
  sensor->version = 1;
  sensor->sensor_id = _sensorID;
  sensor->type = SENSOR_TYPE_AMBIENT_TEMPERATURE;
  sensor->min_delay = 0;
  sensor->min_value = -40;
  sensor->max_value = 85;
  sensor->resolution = 1; /* not a great sensor */
}

/**************************************************************************/
/*!
    @brief  Gets the temperature as a standard sensor event
    @param  event Sensor event object that will be populated
    @returns True
*/
/**************************************************************************/
bool LSM6DS_Temp::getEvent(sensors_event_t *event) {
  _theLSM6DS->_read();
  _theLSM6DS->fillTempEvent(event, millis());

  return true;
}

/**************************************************************************/
/*!
    @brief Enables and disables the wakeup function
    @param enable True to turn on the wakeup function, false to turn off
    @param status True to report status on INT1, false to report change
    @param wakeup_duration How many > threshold readings to generate a wakeup
    @param thresh The threshold (sensitivity)
    @param sleep_duration How many readings to determine inactivity
    @param hpf True for high pass filter, false for slope filter
*/
/**************************************************************************/
void LSM6DS::enableActivityInactivity(bool enable, bool status, uint8_t wakeup_duration, uint8_t thresh, uint8_t sleep_duration, bool hpf) {
  // enable/disable basic interrupts
  Adafruit_BusIO_Register cfg2 = Adafruit_BusIO_Register(i2c_dev, TAP_CFG2);
  Adafruit_BusIO_RegisterBits int_enable = Adafruit_BusIO_RegisterBits(&cfg2, 1, 7);
  int_enable.write(enable);
  // enable/disable activity/inactivity event to INT1
  Adafruit_BusIO_Register md1 = Adafruit_BusIO_Register(i2c_dev, MD1_CFG);
  Adafruit_BusIO_RegisterBits act_event = Adafruit_BusIO_RegisterBits(&md1, 1, 7);
  act_event.write(enable);

  if (enable) {
    // configure mode
    Adafruit_BusIO_Register cfg2 = Adafruit_BusIO_Register(i2c_dev, TAP_CFG0);
    Adafruit_BusIO_RegisterBits sleep_status = Adafruit_BusIO_RegisterBits(&cfg2, 1, 5);
    sleep_status.write(status);
    // choose hpf or slope filter
    Adafruit_BusIO_RegisterBits slope_fds = Adafruit_BusIO_RegisterBits(&cfg2, 1, 4);
    slope_fds.write(hpf);
    // set duration
    Adafruit_BusIO_Register dur = Adafruit_BusIO_Register(i2c_dev, WAKE_UP_DUR);
    Adafruit_BusIO_RegisterBits wk_dur = Adafruit_BusIO_RegisterBits(&dur, 2, 5);
    wk_dur.write(wakeup_duration); // 1 LSB = 1 ODR time
    Adafruit_BusIO_RegisterBits sleep_dur = Adafruit_BusIO_RegisterBits(&dur, 4, 0);
    sleep_dur.write(sleep_duration); // 1 LSB = 512 ODR time
    // set threshold
    Adafruit_BusIO_Register ths = Adafruit_BusIO_Register(i2c_dev, WAKE_UP_THS);
    Adafruit_BusIO_RegisterBits wk_ths = Adafruit_BusIO_RegisterBits(&ths, 6, 0);
    wk_ths.write(thresh);
  }
}

/**************************************************************************/
/*!
    @brief Checks interrupt register to see if we have a change event in activity/inactivity status
    @returns True if activity event bit is set in WAKEUP_SRC (cleared on read)
*/
/**************************************************************************/
bool LSM6DS::activityEvent(void) {
  Adafruit_BusIO_Register wakesrc = Adafruit_BusIO_Register(i2c_dev, WAKE_UP_SRC);
  Adafruit_BusIO_RegisterBits act_evt = Adafruit_BusIO_RegisterBits(&wakesrc, 1, 6);
  return act_evt.read();
}

/**************************************************************************/
/*!
    @brief Checks interrupt register for sleep status
    @returns True if sleep status bit is set in WAKEUP_SRC (true for inactivity, false for activity)
*/
/**************************************************************************/
bool LSM6DS::activityStatus(void) {
  Adafruit_BusIO_Register wakesrc = Adafruit_BusIO_Register(i2c_dev, WAKE_UP_SRC);
  Adafruit_BusIO_RegisterBits sleep_status = Adafruit_BusIO_RegisterBits(&wakesrc, 1, 4);
  return sleep_status.read();
}

/**************************************************************************/
/*!
    @brief Gets the accelerometer data rate.
    @returns The data rate in float
*/
float LSM6DS::accelerationSampleRate(void) {
  return _data_rate_arr[this->getAccelDataRate()];
}

/**************************************************************************/
/*!
    @brief Check for available data from accelerometer
    @returns 1 if available, 0 if not
*/
int LSM6DS::accelerationAvailable(void) {
  return (this->status() & 0x01) ? 1 : 0;
}

/**************************************************************************/
/*!
    @brief Read accelerometer data
    @param x reference to x axis
    @param y reference to y axis
    @param z reference to z axis
    @returns 1 if success, 0 if not
*/
int LSM6DS::readAcceleration(float &x, float &y, float &z) {
  int16_t data[3];

  Adafruit_BusIO_Register accel_data = Adafruit_BusIO_Register(i2c_dev, OUT_A, 6);

  if (!accel_data.read((uint8_t *)data, sizeof(data))) {
    x = y = z = NAN;
    return 0;
  }

  // scale to range of -4 – 4
  x = data[0] * 4.0 / 32768.0;
  y = data[1] * 4.0 / 32768.0;
  z = data[2] * 4.0 / 32768.0;

  return 1;
}